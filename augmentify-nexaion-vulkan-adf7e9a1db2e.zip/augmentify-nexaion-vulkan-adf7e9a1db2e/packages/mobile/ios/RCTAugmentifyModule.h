#import <React/RCTBridgeModule.h>
@interface RCTAugmentifyModule : NSObject <RCTBridgeModule>
@end
