describe('sessionService', () => {
  // eslint-disable-next-line jest/expect-expect
  it('happy day', () => {});
});
