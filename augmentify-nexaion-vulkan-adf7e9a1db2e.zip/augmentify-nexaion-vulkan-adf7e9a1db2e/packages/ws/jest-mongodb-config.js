module.exports = {
  mongodbMemoryServerOptions: {
    binary: {
      version: '4.2.9',
      skipMD5: true,
    },
    instance: {},
    autoStart: false,
  },
};
