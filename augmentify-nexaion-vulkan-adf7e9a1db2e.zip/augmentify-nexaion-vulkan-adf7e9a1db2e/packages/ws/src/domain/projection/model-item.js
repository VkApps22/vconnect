export default [
  'codePattern',
  'nameKey',
  'name',
  'familyKey',
  'family',
  'model',
  'thumbnail',
  'createdDate',
  'modifiedDate',
];
