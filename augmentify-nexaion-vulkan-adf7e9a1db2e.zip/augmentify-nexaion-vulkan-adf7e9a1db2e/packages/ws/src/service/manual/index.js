export { default as fetchManualService } from './fetch';
export { default as addReviewManualService } from './add-review';
export { default as downloadManualService } from './download';
