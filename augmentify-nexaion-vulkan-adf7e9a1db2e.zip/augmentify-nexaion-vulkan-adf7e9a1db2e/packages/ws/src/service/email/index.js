export { default as sendEmailService } from './send';
