export { default as fetchContactService } from './fetch';
